import * as grpc from '@grpc/grpc-js';
import { SzGrpcEnvironmentOptions } from '../szGrpcEnvironment';
export declare abstract class SzGrpcBase {
    /** @ignore */
    abstract client: any;
    /** metadata passed to the request context
     * @ignore
    */
    protected _metadata: grpc.Metadata;
    private grpcOptions;
    grpcConnectionReadyTimeOut: number;
    protected getDeadlineFromNow(secondsFromNow?: number): Date;
    /**
     * Wait for the client to be ready. The callback will be called when the client has successfully connected to the server, and it will be called with an error if the attempt to connect to the server has unrecoverablly failed or if the deadline expires. This function will make the channel start connecting if it has not already done so.
     */
    waitForReady(deadline: Date, cb: (error: Error | null) => void): any;
    constructor(options: SzGrpcEnvironmentOptions);
}
