"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SzGrpcBase = void 0;
const grpc = __importStar(require("@grpc/grpc-js"));
const szGrpcEnvironment_1 = require("../szGrpcEnvironment");
class SzGrpcBase {
    getDeadlineFromNow(secondsFromNow) {
        let retVal = new Date();
        retVal.setSeconds(retVal.getSeconds() + (secondsFromNow ? secondsFromNow : this.grpcConnectionReadyTimeOut));
        return retVal;
    }
    /**
     * Wait for the client to be ready. The callback will be called when the client has successfully connected to the server, and it will be called with an error if the attempt to connect to the server has unrecoverablly failed or if the deadline expires. This function will make the channel start connecting if it has not already done so.
     */
    waitForReady(deadline, cb) {
        return this.client?.waitForReady(deadline, cb);
    }
    constructor(options) {
        /** metadata passed to the request context
         * @ignore
        */
        this._metadata = new grpc.Metadata({ waitForReady: true });
        this.grpcOptions = szGrpcEnvironment_1.DEFAULT_CHANNEL_OPTIONS;
        this.grpcConnectionReadyTimeOut = szGrpcEnvironment_1.DEFAULT_CONNECTION_READY_TIMEOUT;
        const { connectionString, credentials, client, grpcOptions, grpcConnectionReadyTimeOut } = options;
        if (grpcConnectionReadyTimeOut) {
            this.grpcConnectionReadyTimeOut = grpcConnectionReadyTimeOut;
        }
    }
}
exports.SzGrpcBase = SzGrpcBase;
//# sourceMappingURL=szGrpcBase.js.map